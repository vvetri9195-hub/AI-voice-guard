"""
VoiceGuard AI — Deep Latent Foundation Model Training Pipeline
Target: 50,000 Samples (25,000 Real Human Voices + 25,000 Ultra-Realistic AI Cloned Voices)
Architecture: facebook/wav2vec2-base + Multi-Layer Perceptron Forensic Head
Export: ONNX (opset 14) matching VoiceGuard Java Spring Boot Engine

Run on GPU (Google Colab / Kaggle / Local CUDA):
    pip install torch torchaudio transformers datasets soundfile numpy onnx onnxruntime
    python train_voiceguard.py --batch_size 16 --epochs 5 --lr 2e-5
"""

import os
import sys
import math
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torchaudio
import torchaudio.transforms as T

# ==========================================
# 1. Forensic Model Architecture
# ==========================================
class VoiceGuardForensicModel(nn.Module):
    """
    Wav2Vec2-Base + Multi-Layer Perceptron (MLP) Forensic Classification Head.
    Matches the exact graph structure expected by VoiceGuard's OnnxModelDetector.java:
      - Input: 'waveform' [1, num_samples] (16kHz float32)
      - Output: 'probabilities' [1, 2] (index 0 = Real, index 1 = Fake)
    """
    def __init__(self, pretrained_model_name="facebook/wav2vec2-base", freeze_encoder=False):
        super().__init__()
        from transformers import Wav2Vec2Model
        if os.path.exists("models/wav2vec2-base/pytorch_model.bin") and pretrained_model_name == "facebook/wav2vec2-base":
            pretrained_model_name = os.path.abspath("models/wav2vec2-base")
        self.wav2vec2 = Wav2Vec2Model.from_pretrained(pretrained_model_name)
        
        if freeze_encoder:
            for param in self.wav2vec2.parameters():
                param.requires_grad = False
            # Unfreeze top transformer layer for fine-tuning
            for param in self.wav2vec2.encoder.layers[-1].parameters():
                param.requires_grad = True
                
        hidden_dim = self.wav2vec2.config.hidden_size # 768
        
        # Dual-layer temporal pooling representation (mean across last two layers)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 2)
        )
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, waveform):
        # Extract Wav2Vec2 hidden states
        outputs = self.wav2vec2(waveform, output_hidden_states=True)
        hidden_states = outputs.hidden_states
        
        # Pool across last two transformer layers (10 and 11)
        h_last = hidden_states[-1].mean(dim=1)   # [batch, 768]
        h_prev = hidden_states[-2].mean(dim=1)   # [batch, 768]
        pooled = torch.cat([h_last, h_prev], dim=-1) # [batch, 1536]
        
        logits = self.head(pooled) # [batch, 2]
        probabilities = self.softmax(logits) # [batch, 2]
        return probabilities


# ==========================================
# 2. Audio Augmentation (Real-World Robustness)
# ==========================================
class AudioAugmentor:
    """
    Augments real human audio with real-world noise (background chatter, room reverb,
    telephony codecs) so the model does not confuse background noise with AI synthesis.
    """
    def __init__(self, sample_rate=16000):
        self.sample_rate = sample_rate

    def add_white_noise(self, audio, snr_db_range=(10, 25)):
        snr_db = random.uniform(*snr_db_range)
        sig_p = torch.mean(audio ** 2)
        noise_p = sig_p / (10 ** (snr_db / 10))
        noise = torch.randn_like(audio) * torch.sqrt(noise_p + 1e-9)
        return audio + noise

    def add_volume_jitter(self, audio, gain_db_range=(-6, 6)):
        gain = 10 ** (random.uniform(*gain_db_range) / 20)
        return audio * gain

    def simulate_telephony(self, audio):
        # Bandpass 300Hz - 3400Hz (PSTN / Telephone filter)
        if audio.shape[-1] < 512: return audio
        try:
            return torchaudio.functional.bandpass_biquad(audio, self.sample_rate, 1850.0, Q=0.7)
        except Exception:
            return audio

    def augment(self, audio, is_real=True):
        # Real human voices get realistic background noise & room acoustics
        if is_real and random.random() < 0.6:
            choice = random.choice(["noise", "telephony", "volume", "all"])
            if choice == "noise":
                audio = self.add_white_noise(audio)
            elif choice == "telephony":
                audio = self.simulate_telephony(audio)
            elif choice == "volume":
                audio = self.add_volume_jitter(audio)
            elif choice == "all":
                audio = self.add_white_noise(audio)
                audio = self.add_volume_jitter(audio)
        return torch.clamp(audio, -1.0, 1.0)


# ==========================================
# 3. 50,000-Sample Balanced Dataset Loader
# ==========================================
class VoiceGuard50kDataset(Dataset):
    """
    Manages 50,000 audio samples:
      - 25,000 Genuine Real Human Voices (class 0)
      - 25,000 Ultra-Realistic AI Cloned Voices (class 1)
    """
    def __init__(self, real_files, ai_files, target_samples=64000, augment=True):
        self.target_samples = target_samples
        self.augment = augment
        self.augmentor = AudioAugmentor(sample_rate=16000)
        
        # Subsample or balance to exactly 25k each if more are supplied
        random.seed(42)
        if len(real_files) > 25000:
            real_files = random.sample(real_files, 25000)
        if len(ai_files) > 25000:
            ai_files = random.sample(ai_files, 25000)
            
        self.samples = [(f, 0) for f in real_files] + [(f, 1) for f in ai_files]
        random.shuffle(self.samples)
        
        print(f"[+] Loaded VoiceGuard Dataset: {len(real_files):,} Real + {len(ai_files):,} AI = {len(self.samples):,} Total Samples")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        file_path, label = self.samples[idx]
        try:
            waveform, sr = torchaudio.load(file_path)
            if sr != 16000:
                resampler = T.Resample(sr, 16000)
                waveform = resampler(waveform)
            if waveform.shape[0] > 1:
                waveform = waveform.mean(dim=0, keepdim=True)
                
            waveform = waveform.squeeze(0) # [samples]
            
            # Active energy cropping or padding to exactly 64,000 samples (4.0s)
            if len(waveform) > self.target_samples:
                # Find segment with highest speech energy
                hop = 8000
                best_start = 0
                max_energy = -1.0
                for s in range(0, len(waveform) - self.target_samples, hop):
                    energy = torch.sum(waveform[s:s+self.target_samples] ** 2).item()
                    if energy > max_energy:
                        max_energy = energy
                        best_start = s
                waveform = waveform[best_start:best_start + self.target_samples]
            elif len(waveform) < self.target_samples:
                pad_len = self.target_samples - len(waveform)
                waveform = F.pad(waveform, (0, pad_len))

            # Apply RMS normalization (match VoiceGuard AudioProcessor: target RMS 0.1)
            rms = torch.sqrt(torch.mean(waveform ** 2) + 1e-9)
            if rms > 1e-6:
                gain = torch.clamp(0.1 / rms, 0.001, 1000.0)
                waveform = waveform * gain

            # Data augmentation for robust generalization
            if self.augment:
                waveform = self.augmentor.augment(waveform, is_real=(label == 0))

            return waveform.float(), torch.tensor(label, dtype=torch.long)
        except Exception as e:
            # Fallback for corrupted audio files
            dummy = torch.zeros(self.target_samples, dtype=torch.float32)
            return dummy, torch.tensor(label, dtype=torch.long)


# ==========================================
# 4. Training Engine
# ==========================================
def train_epoch(model, dataloader, optimizer, criterion, scaler, device):
    model.train()
    total_loss = 0.0
    correct = 0
    total = 0
    
    for step, (waveforms, labels) in enumerate(dataloader):
        waveforms = waveforms.to(device)
        labels = labels.to(device)
        
        optimizer.zero_grad()
        with torch.amp.autocast('cuda', enabled=(device.type == "cuda")):
            probs = model(waveforms) # [batch, 2]
            # Use log probabilities with NLL loss for numeric stability
            log_probs = torch.log(probs + 1e-9)
            loss = criterion(log_probs, labels)
            
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        
        total_loss += loss.item() * waveforms.size(0)
        preds = torch.argmax(probs, dim=-1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)
        
        if (step + 1) % 50 == 0 or (step + 1) == len(dataloader):
            acc = correct / total * 100.0
            print(f"  Step [{step+1}/{len(dataloader)}] | Loss: {loss.item():.4f} | Running Acc: {acc:.2f}%")
            
    return total_loss / total, (correct / total * 100.0)

def evaluate(model, dataloader, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for waveforms, labels in dataloader:
            waveforms = waveforms.to(device)
            labels = labels.to(device)
            probs = model(waveforms)
            preds = torch.argmax(probs, dim=-1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
    return (correct / total * 100.0) if total > 0 else 0.0


# ==========================================
# 5. Export to VoiceGuard ONNX Engine
# ==========================================
def export_onnx(model, output_path="voice_detector_foundation.onnx"):
    model.eval()
    dummy_input = torch.randn(1, 64000, dtype=torch.float32)
    
    print(f"\n[*] Exporting trained model to ONNX: {output_path}...")
    torch.onnx.export(
        model.cpu(),
        dummy_input,
        output_path,
        export_params=True,
        opset_version=14,
        do_constant_folding=True,
        input_names=["waveform"],
        output_names=["probabilities"],
        dynamic_axes={
            "waveform": {0: "batch_size", 1: "num_samples"},
            "probabilities": {0: "batch_size"}
        }
    )
    print(f"[+] Successfully exported {output_path} ({os.path.getsize(output_path)/(1024*1024):.2f} MB)")
    print("[+] Model matches VoiceGuard Spring Boot input ['waveform'] and output ['probabilities']!")


# ==========================================
# 6. Main Orchestrator
# ==========================================
def main():
    parser = argparse.ArgumentParser(description="VoiceGuard AI 50k Training Pipeline")
    parser.add_argument("--real_dir", type=str, default="data/real", help="Directory of 25,000 real human voice WAV/FLAC files")
    parser.add_argument("--ai_dir", type=str, default="data/ai", help="Directory of 25,000 synthetic AI voice WAV/FLAC files")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size for training")
    parser.add_argument("--epochs", type=int, default=5, help="Number of training epochs")
    parser.add_argument("--lr", type=float, default=2e-5, help="Learning rate for AdamW")
    parser.add_argument("--freeze_encoder", action="store_true", default=False, help="Freeze Wav2Vec2 encoder for fast training")
    parser.add_argument("--output_onnx", type=str, default="src/main/resources/models/voice_detector_foundation.onnx")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[*] VoiceGuard Training Pipeline initiated on device: {device}")

    # Discover training files
    real_files = []
    if os.path.exists(args.real_dir):
        for root, _, files in os.walk(args.real_dir):
            for f in files:
                if f.lower().endswith((".wav", ".flac", ".mp3")):
                    real_files.append(os.path.join(root, f))

    ai_files = []
    if os.path.exists(args.ai_dir):
        for root, _, files in os.walk(args.ai_dir):
            for f in files:
                if f.lower().endswith((".wav", ".flac", ".mp3")):
                    ai_files.append(os.path.join(root, f))

    print(f"[*] Discovered: {len(real_files):,} Real audio files | {len(ai_files):,} AI audio files")

    # If directories don't have files, guide user to public datasets
    if len(real_files) < 10 or len(ai_files) < 10:
        print("\n" + "="*70)
        print("⚠️  DATASET DIRECTORIES EMPTY OR INSUFFICIENT SAMPLES")
        print("="*70)
        print("To train on 25,000 Real + 25,000 AI samples, use standard open benchmarks:")
        print("  1. Real Voices (25k): Mozilla Common Voice (English + Tamil), LibriSpeech, or VCTK")
        print("  2. AI Voices (25k): ASVspoof 2019/2021 LA (A01-A19), In-The-Wild Deepfake, FakeAVCeleb")
        print("Download/extract into:")
        print(f"  Real voices -> {args.real_dir}/")
        print(f"  AI voices   -> {args.ai_dir}/")
        print("="*70 + "\n")
        return

    # Train / Validation Split (90% Train, 10% Validation)
    random.shuffle(real_files)
    random.shuffle(ai_files)
    
    n_real_val = int(len(real_files) * 0.1)
    n_ai_val = int(len(ai_files) * 0.1)
    
    train_dataset = VoiceGuard50kDataset(real_files[n_real_val:], ai_files[n_ai_val:], augment=True)
    val_dataset = VoiceGuard50kDataset(real_files[:n_real_val], ai_files[:n_ai_val], augment=False)
    
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=(device.type == "cuda"))
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)

    # Initialize model
    model = VoiceGuardForensicModel("facebook/wav2vec2-base", freeze_encoder=args.freeze_encoder).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    criterion = nn.NLLLoss()
    scaler = torch.amp.GradScaler('cuda', enabled=(device.type == "cuda"))

    print(f"[*] Commencing training: {args.epochs} epochs | Batch size: {args.batch_size} | Samples: {len(train_dataset):,}")
    best_acc = 0.0

    for epoch in range(1, args.epochs + 1):
        print(f"\n--- Epoch [{epoch}/{args.epochs}] ---")
        train_loss, train_acc = train_epoch(model, train_loader, optimizer, criterion, scaler, device)
        val_acc = evaluate(model, val_loader, device)
        print(f"Epoch {epoch} Complete | Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}% | Val Acc: {val_acc:.2f}%")
        
        if val_acc > best_acc:
            best_acc = val_acc
            from safetensors.torch import save_file
            save_file(model.state_dict(), "voiceguard_best_checkpoint.safetensors")
            print(f"[*] New checkpoint saved with validation accuracy: {best_acc:.2f}%")

    # Export best model to ONNX
    from safetensors.torch import load_file
    model.load_state_dict(load_file("voiceguard_best_checkpoint.safetensors"))
    export_onnx(model, args.output_onnx)
    print("\n[✓] Training and ONNX export completed successfully!")

if __name__ == "__main__":
    main()
