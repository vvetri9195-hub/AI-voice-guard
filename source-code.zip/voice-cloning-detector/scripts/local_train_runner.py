import os
import sys
import subprocess
import time

print("[*] VoiceGuard AI Local Training Orchestrator Started")

# Ensure directories exist
os.makedirs("data/real", exist_ok=True)
os.makedirs("data/ai", exist_ok=True)

real_files = [f for f in os.listdir("data/real") if f.endswith((".wav", ".flac"))]
ai_files = [f for f in os.listdir("data/ai") if f.endswith((".wav", ".flac"))]

print(f"[*] Found {len(real_files):,} Real files and {len(ai_files):,} AI files in local directories.")

# Launch train_voiceguard.py with stdout logged directly to scratch/local_training.log
log_path = os.path.abspath("scratch/local_training.log")
log_file = open(log_path, "w", encoding="utf-8")

cmd = [
    sys.executable, "-u", "train_voiceguard.py",
    "--real_dir", "data/real",
    "--ai_dir", "data/ai",
    "--batch_size", "8",
    "--epochs", "3",
    "--freeze_encoder"
]
proc = subprocess.Popen(cmd, stdout=log_file, stderr=subprocess.STDOUT)

print(f"[✓] Local background training launched with PID: {proc.pid}")
print(f"[✓] Output log streaming to: {log_path}")
print("[✓] Process running in background. You can monitor with: Get-Content scratch/local_training.log -Tail 20")
