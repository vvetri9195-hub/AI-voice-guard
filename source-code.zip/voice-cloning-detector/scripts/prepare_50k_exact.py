import os
import shutil
import soundfile as sf
import numpy as np

print("[*] Preparing FULL 50,000 Samples (25,000 Real + 25,000 AI)...")

os.makedirs("data/real", exist_ok=True)
os.makedirs("data/ai", exist_ok=True)

# 1. Collect all Bonafide (Real) and Spoof (AI) paths from ASVspoof 2019 protocols
splits = [
    ("train", "dataset/LA/ASVspoof2019_LA_train/flac", "dataset/LA/ASVspoof2019_LA_cm_protocols/ASVspoof2019.LA.cm.train.trn.txt"),
    ("dev",   "dataset/LA/ASVspoof2019_LA_dev/flac",   "dataset/LA/ASVspoof2019_LA_cm_protocols/ASVspoof2019.LA.cm.dev.trl.txt"),
    ("eval",  "dataset/LA/ASVspoof2019_LA_eval/flac",  "dataset/LA/ASVspoof2019_LA_cm_protocols/ASVspoof2019.LA.cm.eval.trl.txt")
]

all_bonafide = []
all_spoof = []

for name, flac_dir, proto in splits:
    if os.path.exists(proto) and os.path.exists(flac_dir):
        with open(proto, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 5:
                    fid = parts[1]
                    label = parts[4]
                    flac_path = os.path.join(flac_dir, fid + ".flac")
                    if os.path.exists(flac_path):
                        if label == "bonafide":
                            all_bonafide.append(flac_path)
                        elif label == "spoof":
                            all_spoof.append(flac_path)

print(f"[*] Total Source Pool: {len(all_bonafide):,} Real (Bonafide) | {len(all_spoof):,} AI (Spoof)")

# 2. Populate data/ai with exactly 25,000 unique AI voice FLAC files via hardlinks
current_ai = set(os.listdir("data/ai"))
needed_ai = 25000 - len(current_ai)
print(f"[*] Populating data/ai to exactly 25,000 files (need {needed_ai:,} more)...")

ai_added = 0
for src in all_spoof:
    fname = os.path.basename(src)
    dst = os.path.join("data/ai", fname)
    if fname not in current_ai:
        try:
            os.link(src, dst)
            current_ai.add(fname)
            ai_added += 1
        except Exception:
            shutil.copyfile(src, dst)
            current_ai.add(fname)
            ai_added += 1
    if len(current_ai) >= 25000:
        break

print(f"[✓] data/ai now contains: {len(os.listdir('data/ai')):,} AI voice files")

# 3. Populate data/real with exactly 25,000 Real human voice files
current_real = set(os.listdir("data/real"))
print(f"[*] Linking initial {len(all_bonafide):,} Real files into data/real...")

for src in all_bonafide:
    fname = os.path.basename(src)
    dst = os.path.join("data/real", fname)
    if fname not in current_real:
        try:
            os.link(src, dst)
            current_real.add(fname)
        except Exception:
            shutil.copyfile(src, dst)
            current_real.add(fname)

print(f"[*] Direct links created. Current real files: {len(current_real):,}. Slicing to reach 25,000...")

# Slicing bonafide files with length > 4s to extract non-overlapping real speech windows
slice_idx = 0
for src in all_bonafide:
    if len(current_real) >= 25000:
        break
    try:
        info = sf.info(src)
        # If longer than 5 seconds, extract a secondary window from offset 3.0s
        if info.duration > 4.5:
            data, sr = sf.read(src, start=int(sr_offset := int(info.samplerate * 2.5)), stop=int(info.samplerate * 6.5))
            if len(data) >= int(info.samplerate * 3.5):
                slice_name = f"slice_{slice_idx:05d}_" + os.path.basename(src)
                dst = os.path.join("data/real", slice_name)
                sf.write(dst, data, sr)
                current_real.add(slice_name)
                slice_idx += 1
    except Exception:
        pass

print(f"[✓] data/real now contains: {len(os.listdir('data/real')):,} Real human voice files")
print(f"\n=======================================================")
print(f"🎉 50,000 SAMPLE DATASET READY:")
print(f"   - REAL Human Voices: {len(os.listdir('data/real')):,}")
print(f"   - AI Cloned Voices:  {len(os.listdir('data/ai')):,}")
print(f"=======================================================")
