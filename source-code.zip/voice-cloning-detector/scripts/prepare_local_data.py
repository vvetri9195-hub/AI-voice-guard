import os
import shutil

os.makedirs('data/real', exist_ok=True)
os.makedirs('data/ai', exist_ok=True)

train_flac_dir = 'dataset/LA/ASVspoof2019_LA_train/flac'
protocol = 'dataset/LA/ASVspoof2019_LA_cm_protocols/ASVspoof2019.LA.cm.train.trn.txt'

bonafide_count = 0
spoof_count = 0
target_per_class = 2000

# Clear existing non-matching files in data/real and data/ai
for f in os.listdir('data/real'):
    if not f.endswith('.flac'):
        try: os.remove(os.path.join('data/real', f))
        except: pass
for f in os.listdir('data/ai'):
    if not f.endswith('.flac'):
        try: os.remove(os.path.join('data/ai', f))
        except: pass

with open(protocol, 'r', encoding='utf-8') as f:
    for line in f:
        parts = line.strip().split()
        if len(parts) >= 5:
            fid = parts[1]
            label = parts[4]
            flac_path = os.path.join(train_flac_dir, fid + '.flac')
            if os.path.exists(flac_path):
                if label == 'bonafide' and bonafide_count < target_per_class:
                    dst = os.path.join('data/real', fid + '.flac')
                    if not os.path.exists(dst):
                        shutil.copyfile(flac_path, dst)
                    bonafide_count += 1
                elif label == 'spoof' and spoof_count < target_per_class:
                    dst = os.path.join('data/ai', fid + '.flac')
                    if not os.path.exists(dst):
                        shutil.copyfile(flac_path, dst)
                    spoof_count += 1
                if bonafide_count >= target_per_class and spoof_count >= target_per_class:
                    break

real_total = len([f for f in os.listdir('data/real') if f.endswith('.flac')])
ai_total = len([f for f in os.listdir('data/ai') if f.endswith('.flac')])
print(f"[✓] Balanced local dataset ready:")
print(f"    - Real Human Voices (Bonafide): {real_total} FLAC files")
print(f"    - AI Cloned Voices (Spoof):    {ai_total} FLAC files")
