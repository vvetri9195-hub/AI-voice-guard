import os
import random
import soundfile as sf
import numpy as np

print("[*] Generating Noise-Augmented Real Human Voices to reach exactly 25,000...")

real_dir = "data/real"
existing_files = [f for f in os.listdir(real_dir) if f.endswith((".flac", ".wav")) and not f.startswith("noiseaug_")]
needed = 25000 - len(os.listdir(real_dir))

print(f"[*] Base real voice files available: {len(existing_files):,}")
print(f"[*] Additional real voice files needed: {needed:,}")

if needed > 0:
    count = 0
    # Deterministic seed for scientific reproducibility
    np.random.seed(42)
    random.seed(42)
    
    for f in existing_files:
        if count >= needed:
            break
        src_path = os.path.join(real_dir, f)
        try:
            data, sr = sf.read(src_path, dtype='float32')
            if len(data.shape) > 1:
                data = data[:, 0]
                
            # Acoustic Noise Augmentation (SNR 12 dB to 25 dB)
            # Simulates background cafe ambient / fan / room acoustics
            snr_db = np.random.uniform(12.0, 25.0)
            sig_p = np.mean(data ** 2)
            if sig_p > 1e-9:
                noise_p = sig_p / (10.0 ** (snr_db / 10.0))
                noise = np.random.normal(0, np.sqrt(noise_p), size=data.shape).astype(np.float32)
                augmented = np.clip(data + noise, -1.0, 1.0)
            else:
                augmented = data

            dst_name = f"noiseaug_{count:05d}_" + f
            dst_path = os.path.join(real_dir, dst_name)
            sf.write(dst_path, augmented, sr)
            count += 1
            if count % 2000 == 0 or count == needed:
                print(f"  [+] Generated {count:,}/{needed:,} noise-augmented real human voice clips...")
        except Exception as e:
            continue

final_real = len([f for f in os.listdir(real_dir) if f.endswith((".flac", ".wav"))])
final_ai = len([f for f in os.listdir("data/ai") if f.endswith((".flac", ".wav"))])

print("\n" + "="*70)
print("🎯 EXACT 50,000 DATASET REACHED:")
print(f"   ├── REAL Human Voices (Bonafide + Ambient Noise): {final_real:,}")
print(f"   └── AI Cloned Voices (Ultra-Realistic Spoof):     {final_ai:,}")
print("="*70)
