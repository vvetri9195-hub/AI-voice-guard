import os
import sys
import subprocess
import time

print("="*70)
print("🚀 VOICEGUARD AI — 50,000 SAMPLE LOCAL TRAINING LAUNCHER")
print("="*70)

# 1. Verify 50,000 samples on disk
real_count = len([f for f in os.listdir("data/real") if f.endswith((".flac", ".wav"))])
ai_count = len([f for f in os.listdir("data/ai") if f.endswith((".flac", ".wav"))])

print(f"[*] Verified Dataset:")
print(f"    - Real Human Voices: {real_count:,}")
print(f"    - AI Cloned Voices:  {ai_count:,}")
print(f"    - Total Samples:     {real_count + ai_count:,}")

if real_count < 25000 or ai_count < 25000:
    print(f"⚠️ Warning: Expected 25,000 each, found Real={real_count}, AI={ai_count}")

# 2. Verify wav2vec2-base download
model_bin = "models/wav2vec2-base/pytorch_model.bin"
if not os.path.exists(model_bin) or os.path.getsize(model_bin) < 350 * 1024 * 1024:
    raise RuntimeError(f"Base model weights missing or incomplete: {model_bin}")

print("[✓] Pretrained Wav2Vec2-Base weights verified 100% on disk!")

# 3. Launch training
log_path = os.path.abspath("scratch/training_50k.log")
log_file = open(log_path, "w", encoding="utf-8")

cmd = [
    sys.executable, "-u", "train_voiceguard.py",
    "--real_dir", "data/real",
    "--ai_dir", "data/ai",
    "--batch_size", "16",
    "--epochs", "5",
    "--lr", "2e-5",
    "--freeze_encoder"
]

print(f"[*] Launching: {' '.join(cmd)}")
proc = subprocess.Popen(cmd, stdout=log_file, stderr=subprocess.STDOUT)

print("\n" + "="*70)
print(f"✅ Local 50k Training successfully launched in background!")
print(f"   - Process PID: {proc.pid}")
print(f"   - Log output:  {log_path}")
print(f"   - Monitor via: Get-Content scratch/training_50k.log -Tail 30 -Wait")
print("="*70)
